<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mpr');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'YES');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'mKxj*o=Yq5C0GH~[c)vlummT+AH{m+KvToRFK2lk-T17]gCG@D#-fxo=CQedY>Jw');
define('SECURE_AUTH_KEY',  '|fpuLfHtm1.CDGpw)grsw+~1YNiak4zpwkn!^hGoTm>[BecJ&@%n,uG;7-F+,nk(');
define('LOGGED_IN_KEY',    'Gjfzi|P$/>#In@wwG$~1R9n76B6L[A2@_H!%don;FC}|E|!==|a.7?&Feez=eDAP');
define('NONCE_KEY',        '72Fvikd~ki,A;K39~nG!+4sF]v3**>-4{~;}js.NE+ge65 ZGQ(Ro~NcO~rH~^8~');
define('AUTH_SALT',        ')Ji?vQA^>v11l~TiE$Hi|NW[*r`P)FH3>}:3]npoWcT=6K=MqwDC)l(E#+*JJm$z');
define('SECURE_AUTH_SALT', 'UO%w!iS1p#o|K -~7eje2VMj+;D_@4!D$Fx7UF]`K,i>tUf%#+OeF4H.k9!)}JTR');
define('LOGGED_IN_SALT',   'cGn4auB9t^LOx#zQZ]TK07+QafLd^c2:f+rg+&!B3_DR|N(*Z+5e,m6V+0uF1+7r');
define('NONCE_SALT',       'Uqq`f.-;GQi5$[)F,ICqE-2%{p.<M&IZ]l-si9!q]ANUudo[t;|A/>$^IdXw77NS');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
